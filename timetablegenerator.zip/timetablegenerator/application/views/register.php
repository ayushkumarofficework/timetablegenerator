<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Easy Timetable</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="<?php echo $base_url; ?>/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="<?php echo $base_url; ?>/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<header>
<nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper container"><a id="logo-container" href="<?php echo $base_url; ?>" class="brand-logo">Logo</a>
      <ul class="right hide-on-med-and-down">
        <li><a href="#">Navbar Link</a></li>
      </ul>

      <ul id="nav-mobile" class="side-nav">
        <li><a href="#">Navbar Link</a></li>
      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>
</header>
<div>

</div>
<body>
<div class="container">
<div class="row center">
        <div class="col s12 m12">
          <div class="card lime lighten-5">
            <div class="card-content black-text">
              <span class="card-title">Technical Advisor Register</span>
              <p><div class="container"><div class="row center">
                    
  <div class="row">
    <form class="col s12" method="post" action="<?php echo $base_url; ?>/index.php/register/registerUser">
      <div class="row">
        <div class="input-field col s4">
          <input placeholder="Name" id="name" name="name" type="text" class="validate">
          
        </div>
		<div class="input-field col s4">
          <input placeholder="Semester" id="semester" name="semester" type="number" class="validate">
          
        </div>
		<div class="input-field col s4">
          <input placeholder="Branch" id="branch" type="text" name="branch" class="validate">
          
        </div>
        
      </div>
      <div class="row">
        <div class="input-field col s12">
          <input id="email" placeholder="Email" type="email" name="email" class="validate">
          
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <input id="password" placeholder="Password" type="password" name="password" class="validate">
          
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
        <input id="confirmpassword" placeholder="Confirm Password" type="password" name="confirmpassword" class="validate">
        </div>
      </div>
	  <div class="card-action">
              <input type="submit" class="waves-effect waves-light btn" value="REGISTER">
              
            </div>
    </form>
  </div>
               </div></div>
        </p>
            </div>
            
          </div>
        </div>
      </div>
</div>	  

</body>
<footer class="page-footer orange">
    <div class="container">
      <div class="row">
        <div class="col l6 s12">
          <h5 class="white-text">Company Bio</h5>
          <p class="grey-text text-lighten-4">We are a team of college students working on this project like it's our full time job. Any amount would help support and continue development on this project and is greatly appreciated.</p>


        </div>
        <div class="col l3 s12">
          <h5 class="white-text">Settings</h5>
          <ul>
            <li><a class="white-text" href="#!">Link 1</a></li>
            <li><a class="white-text" href="#!">Link 2</a></li>
            <li><a class="white-text" href="#!">Link 3</a></li>
            <li><a class="white-text" href="#!">Link 4</a></li>
          </ul>
        </div>
        <div class="col l3 s12">
          <h5 class="white-text">Connect</h5>
          <ul>
            <li><a class="white-text" href="#!">Link 1</a></li>
            <li><a class="white-text" href="#!">Link 2</a></li>
            <li><a class="white-text" href="#!">Link 3</a></li>
            <li><a class="white-text" href="#!">Link 4</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
      Made by <a class="orange-text text-lighten-3" href="http://materializecss.com">Materialize</a>
      </div>
    </div>
  </footer>


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="<?php echo $base_url; ?>/js/materialize.js"></script>
  <script src="<?php echo $base_url; ?>/js/init.js"></script>

  </html>
