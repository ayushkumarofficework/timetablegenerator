<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Easy Timetable</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="<?php echo $base_url; ?>/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="<?php echo $base_url; ?>/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <script src="../code.jquery.com/jquery-2.1.1.min.js"></script>
    <script>if (!window.jQuery) { document.write('<script src="bin/jquery-2.1.1.min.html"><\/script>'); }
    </script>
    <script src="js/jquery.timeago.min.js"></script>  
    <script src="js/prism.js"></script>
    <script src="bin/materialize.js"></script>
    <script src="js/init.js"></script>
</head>
<div>
<header>
<nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper">
      <a href="#" class="brand-logo center">Logo</a>
     
	  </div>
  </nav>
</header>
</div>
<body>
<header>
<div class="container"><a href="#" data-activates="nav-mobile" class="button-collapse top-nav waves-effect waves-light circle hide-on-large-only">
<i class="mdi-navigation-menu"></i></a></div>
<ul id="nav-mobile" class="side-nav fixed">
        <li class="logo"><a id="logo-container" href="" class="brand-logo">
            <h2>LOGO</h2></a></li>
        <li class="bold"><a href="<?php echo $base_url; ?>/index.php/createtimetable" class="waves-effect waves-teal active">Create Timetable</a></li>
        <li class="bold"><a href="<?php echo $base_url; ?>/index.php/showtimetablepresent" class="waves-effect waves-teal">Show Timetable</a></li>
        <li class="bold"><a href="<?php echo $base_url; ?>/index.php/updatetimetable" class="waves-effect waves-teal">Update Timetable</a></li>
		<li class="bold"><a href="<?php echo $base_url; ?>/index.php/home/logout" class="waves-effect waves-teal">Logout</a></li>
        
        
      </ul>
	  </header>
<main>
      <div class="section no-pad-bot" id="index-banner">
        <div class="container">
		<div class="row center">
            <h5>Welcome <?php echo $this->session->userdata('name')." "; ?>to</h5>
          </div>
          
          <h1 class="header center">Easy Timetable</h1>
          <div class='row center'>
            <h4 class ="header col s12  center">A modern responsive way to generate Timetable</h4>
          </div>
          

          
          <br>

        </div>
        
      </div>

      <div class="container">
        <div class="section">


          <div class="row">
            <h4 class="col s12 light center header">Cut yourself some slack and generate timetable!</h4>
          </div>

          

        </div>
        <div class="divider"></div>
        
      </div>


    </main>
	</body>
	


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="<?php echo $base_url; ?>/js/materialize.js"></script>
  <script src="<?php echo $base_url; ?>/js/init.js"></script>

  </html>
