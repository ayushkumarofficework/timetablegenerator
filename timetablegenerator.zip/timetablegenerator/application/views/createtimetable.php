<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Easy Timetable</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="<?php echo $base_url; ?>/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="<?php echo $base_url; ?>/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>

    <script>if (!window.jQuery) { document.write('<script src="bin/jquery-2.1.1.min.html"><\/script>'); }
    </script>
   
</head>
<div>
<header>
<nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper">
      <a href="#" class="brand-logo center">Logo</a>
      
    </div>
  </nav>
</header>
</div>
<body>
<header>
<div class="container"><a href="#" data-activates="nav-mobile" class="button-collapse top-nav waves-effect waves-light circle hide-on-large-only">
<i class="mdi-navigation-menu"></i></a></div>
<ul id="nav-mobile" class="side-nav fixed">
        <li class="logo"><a id="logo-container" href="" class="brand-logo">
            <h2>LOGO</h2></a></li>
        <li class="bold"><a href="<?php echo $base_url; ?>/index.php/createtimetable" class="waves-effect waves-teal active">Create Timetable</a></li>
        <li class="bold"><a href="<?php echo $base_url; ?>/index.php/showtimetablepresent" class="waves-effect waves-teal">Show Timetable</a></li>
        <li class="bold"><a href="<?php echo $base_url; ?>/index.php/updatetimetable" class="waves-effect waves-teal">Update Timetable</a></li>
        <li class="bold"><a href="<?php echo $base_url; ?>/index.php/home/logout" class="waves-effect waves-teal">Logout</a></li>
        
      </ul>
</header>
<main>
<?php if($timetable){ ?>
<p align="center">Timetable is already CREATED you can update it if you want or delete it!</p>
<?php } else{ ?>
      <div class="container">
<div class="row center">
        <div class="col s12 m12">
          <div class="card">
            <div class="card-content black-text">
              <span class="card-title">Enter Credentials</span>
              <p><div class="container"><div class="row center">
                    
  <div class="row"  >
    <form class="col s12" id="createtimetableform" action="<?php echo $base_url; ?>/index.php/showtimetable" method="post">
	<div class="container">
      <div class="row center">
        
		<div class="input-field col s12" >
          <input placeholder="Number Of Subjects" id="numberofsubjects" name="numberofsubjects" type="number" class="validate">
          
        </div>
        
      </div></div>
	  <div id="teachercredentials" style="display:none;">
      
	  
	  
	  </div>
      <div id="createtimetablebutton"style="display:none;">
             <input type="submit" class="waves-effect waves-light btn" value="CREATE TIMETABLE" /> 
              
            </div>
    </form>
  </div>
               </div></div>
        </p>
            </div>
            
          </div>
        </div>
      </div>
</div>
<?php } ?>

    </main>
	</body>
	<script src="<?php echo $base_url; ?>/js/jquery.min.js"></script>
	<script src="<?php echo $base_url; ?>/js/materialize.min.js"></script>
	<script src="<?php echo $base_url; ?>/js/jquery.sticky.js"></script>
	<script>
	$('#numberofsubjects').on('keyup',function(){
	var str=$('#numberofsubjects').val();
	
	$.ajax({
		'url':'<?php echo $base_url; ?>/index.php/ajax/assignNumberofsubjects',
		'dataType':'json',
		'type':'post',
		'data':$('#createtimetableform').serialize(),
		'success':function(result){if(result){$('#teachercredentials').css('display','block');$('#createtimetablebutton').css('display','block');}
					for(var i=1;i<=result;i++){
									$('#teachercredentials').append('<div class="row">'+
        '<div class="input-field col s2">'+
          '<input  placeholder="Teacher code" name="teachercode'+i+'" type="text" class="validate">'+
          '</div>'+
		'<div class="input-field col s4">'+
          '<input  placeholder="Teacher name" name="teachername'+i+'" type="text" class="validate">'+
          '</div>'+
		'<div class="input-field col s3">'+
         ' <input  placeholder="Subject" name="subject'+i+'" type="text" class="validate">'+
          ' </div>'+
		  '<div class="input-field col s3">'+
          '<input  placeholder="No of class a week" name="numberofclassesaweek'+i+'" type="number" class="validate">'+
          '</div>'+
      '</div>');	
						
								}
				}
		
	});
	});
	</script>
	</html>