<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php 
class Viewtimetable extends CI_Controller{
	function index(){
		$data['base_url']=$this->config->item('base_url');
		$this->load->view('viewtimetable',$data);
	}
	function viewbysemester(){
		$data['base_url']=$this->config->item('base_url');
		$this->load->model('showtimetablemodel');
		$data['timetable']=$this->showtimetablemodel->getTimetableBySemester();
		$this->load->view('showtimetablebysemester',$data);
	}
}