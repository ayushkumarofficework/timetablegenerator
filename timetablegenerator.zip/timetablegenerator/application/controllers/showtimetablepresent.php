<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php 
class Showtimetablepresent extends CI_Controller{
	function index(){
		$data['base_url']=$this->config->item('base_url');
		$this->load->model('showtimetablemodel');
		$data['timetable']=$this->showtimetablemodel->getTimetable();
		$this->load->view('showtimetable',$data);
	}
}