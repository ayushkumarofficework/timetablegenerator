<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php 
class Home extends CI_Controller{
	function index(){
		$data['base_url']=$this->config->item('base_url');
		if($this->session->has_userdata('logged_in')){
			$this->load->view('account',$data);
		}
		else
		{
			redirect($data['base_url']."/index.php/landing");
		}
	}
	function logout(){
		$baseurl=$this->config->item('base_url');
		session_destroy();
		redirect($baseurl);
	}
}