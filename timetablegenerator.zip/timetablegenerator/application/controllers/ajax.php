<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php 
class Ajax extends CI_Controller{
	public function assignNumberofsubjects(){
		$numberofsubjects=$this->input->post('numberofsubjects');
		$this->session->set_userdata('numberofsubjects',$numberofsubjects);
		echo ($numberofsubjects);
	}
}
?>