<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php class Register extends CI_Controller{
	function index(){
		$data['base_url']=$this->config->item('base_url');
		if($this->session->userdata('logged_in')==true)
			redirect($data['base_url']."/index.php/home");
		else
		$this->load->view('register',$data);
	}
	function registerUser(){
		$data['base_url']=$this->config->item('base_url');
		$this->load->library('form_validation');
		$this->form_validation->set_rules('name','Name','trim|required|min_length[3]|max_length[100]');
	    $this->form_validation->set_rules('email','Email Address','trim|required|min_length[6]|max_length[50]|valid_email|is_unique[facultyadvisors.email]');
		$this->form_validation->set_rules('password','Password','trim|required|min_length[6]|max_length[50]');
		$this->form_validation->set_rules('semester','Semester','trim|required');
		$this->form_validation->set_rules('branch','Branch','trim|required');
		$this->form_validation->set_rules('confirmpassword', 'Confirm password','trim|required|min_length[6]|max_length[50]|matches[password]');
		if($this->form_validation->run()==FALSE){
		    $baseurl=$this->config->item('base_url');
				redirect($baseurl."/index.php/register");
		}
		else{
			$this->load->model('registermodel');
			$data['name']=$this->registermodel->insertFacultyAdvisor();
			if($data['name']){
				$baseurl=$this->config->item('base_url');
				redirect($baseurl."/index.php/home");
			}
		}
	}
	function loginUser(){
		$this->load->library('form_validation');
		$data['base_url']=$this->config->item('base_url');
	    $this->form_validation->set_rules('loginemail','Email Address','trim|required|min_length[6]|max_length[50]|valid_email');
		$this->form_validation->set_rules('loginpassword','Password','trim|required|min_length[6]|max_length[50]');
		 if($this->form_validation->run()==FALSE){
		    $baseurl=$this->config->item('base_url');
				redirect($baseurl."/index.php/login");
		}
		else{
			$this->load->model('registermodel');
			$result=$this->registermodel->loginUser();
			$data['base_url']=$this->config->item('base_url');
			switch($result){
				case 'logged_in':
				    $baseurl=$this->config->item('base_url');
					redirect($baseurl."/index.php/home");
					break;
				case 'incorrect_password':
				    $baseurl=$this->config->item('base_url');
					redirect($baseurl."/index.php/login");
				    break;
				case 'email_not_found':
				    $baseurl=$this->config->item('base_url');
					redirect($baseurl."/index.php/login");
					break;
			}
		}
	}
}