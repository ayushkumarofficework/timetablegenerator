<?php 
class Registermodel extends CI_Model{
	function __construct(){
		parent::__construct();
	}
	function insertFacultyAdvisor(){
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$semester=$this->input->post('semester');
		$branch=$this->input->post('branch');
		$password=$this->input->post('password');
		$sql="INSERT INTO `facultyadvisors` (name,email,password,semester,branch) VALUES(
		'".$name."',
		'".$email."',
		'".$password."',
		'".$semester."',
		'".$branch."')";
		$this->db->query($sql);
		if($this->db->affected_rows())
		{   $this->session->set_userdata('name',$name);
	        $this->session->set_userdata('email',$email);
	        $this->session->set_userdata('branch',$branch);
	        $this->session->set_userdata('semester',$semester);
			$this->session->set_userdata('logged_in',true);
			return $name;
		}
		else
			return "";
	}
	function loginUser(){
		$loginemail=$this->input->post('loginemail');
		$loginpassword=$this->input->post('loginpassword');
		$sql="SELECT * FROM facultyadvisors WHERE email='".$loginemail."'";
		$result=$this->db->query($sql);
		$row=$result->row();
		if($result->num_rows()==1){
			if($row->password==$loginpassword){
				$sess_data=array(
		            'name' => $row->name,
		            'semester' => $row->semester,
		            'email' => $email,
					'branch' => $row->branch,
		            'logged_in' => true);
				$this->session->set_userdata($sess_data);
				return 'logged_in';
			}
			else 
				return 'incorrect_password';
		}
		else
			return 'email_not_found';
	}
}